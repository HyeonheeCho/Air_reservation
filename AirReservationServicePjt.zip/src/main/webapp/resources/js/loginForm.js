function loginFun() {

	console.log('loginFun() INIT!')
	
	var loginFun = document.loginForm;
	
	if(loginFun.m_mail.value == "") {
		alert("Please input your mail address")
		loginFun.m_mail.focus();
		
	} else if(loginFun.m_pw.value == "") {
		alert("Please input your password")
		loginFun.m_pw.focus();
		
	} else {
		loginFun.submit();

	}
}

function adminLoginFun() {

	console.log('loginFun() INIT!')
	
	var loginFun = document.loginForm;
	
	if(loginFun.a_mail.value == "") {
		alert("Please input admin mail address")
		loginFun.a_mail.focus();
		
	} else if(loginFun.a_pw.value == "") {
		alert("Please input admin password")
		loginFun.a_pw.focus();
		
	} else {
		loginFun.submit();

	}
}