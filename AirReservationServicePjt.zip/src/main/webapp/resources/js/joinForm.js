function joinFun() {

	console.log('joinFun() INIT!')
	
	var joinForm = document.joinForm;
	
	if(joinForm.m_mail.value == "") {
		alert("Please input your mail address")
		joinForm.m_mail.focus();
		
	} else if(joinForm.m_pw.value == "") {
		alert("Please input your password")
		joinForm.m_pw.focus();
		
	} else {
		joinForm.submit();

	}
}