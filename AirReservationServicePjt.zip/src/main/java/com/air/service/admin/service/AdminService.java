package com.air.service.admin.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.air.service.admin.dao.AdminDao;
import com.air.service.admin.vo.AdminVo;

@Service
public class AdminService {

	@Autowired
	AdminDao adminDao;
	
	public int loginConfirm(AdminVo adminVo) {
		
		int result = adminDao.loginAdmin(adminVo);
		
		return result;
	}

}
