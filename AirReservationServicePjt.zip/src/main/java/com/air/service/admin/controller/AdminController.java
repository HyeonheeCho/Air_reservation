package com.air.service.admin.controller;

import java.io.InputStream;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;

import com.air.service.admin.service.AdminService;
import com.air.service.admin.vo.AdminVo;
import com.air.service.member.service.MemberService;
import com.air.service.member.vo.MemberVo;
import com.air.service.reservation.service.ReservationService;
import com.air.service.reservation.vo.ReservationVo;

@Controller
@RequestMapping(value="/admin")
public class AdminController {

	@Autowired
	AdminService adminService;
	
	@Autowired
	MemberService memberService;
	
	@Autowired
	ReservationService reservationService;
	
	@RequestMapping(value= "", method = RequestMethod.GET)
	public String admin() {
		
		System.out.println("[AdminController] admin() INIT!");
		
		return "redirect:/admin/";
	}
	
	
	@RequestMapping(value= "/", method = RequestMethod.GET)
	public String adminHome() {
		
		System.out.println("[AdminController] adminHome() INIT!");
		
		return "admin/loginForm";
	}
	
	@RequestMapping(value="/loginConfirm", method=RequestMethod.POST)
	public String loginConfirm(AdminVo adminVo, HttpSession session) {
		
		System.out.println("[AdminController] loginConfirm() INIT!");
		
		int result = adminService.loginConfirm(adminVo);
		
		if (result > 0 ) {
			
			session.setAttribute("admin", adminVo.getA_mail());
			
			return "redirect:/admin/";
			
		} else {
			
			return "redirect:/admin/";
		}
	
	}
	
	@RequestMapping(value="/logout", method=RequestMethod.GET)
	public String logout(HttpSession session) {
		
		System.out.println("[AdminController] logOut() INIT!");
	
		session.invalidate();
	
		return "redirect:/admin/";
	}
	
	
	@RequestMapping(value="/loginForm", method=RequestMethod.GET)
	public String loginForm() {
		
		
		return "redirect:/admin/";
	}
	
	@RequestMapping(value = "/members", method = RequestMethod.GET)
	public String members(Model model) {
		System.out.println("[AdminController] members() INIT");
		
		List<MemberVo> memberVos = memberService.getMembers();
		model.addAttribute("memberVos", memberVos);
		
		return "admin/members";
	}
	
	@RequestMapping(value="/reservations", method=RequestMethod.GET)
	public String reservations(Model model) {
		System.out.println("[AdminController] reservations() INIT");
		
		List<ReservationVo> reservationVos =  reservationService.getReservations();
		model.addAttribute("reservationVos", reservationVos);
		
		return "admin/reservations";
	}
	
	@RequestMapping(value="/reservationModifyForm", method=RequestMethod.GET)
	public String reservationModifyForm(@RequestParam int r_no, Model model) {
		
		System.out.println("[AdminController] reservationModifyForm() INIT");
		ReservationVo reservationVo = reservationService.getReservation(r_no);
		model.addAttribute("reservationVo", reservationVo);
		
		return "admin/reservationModifyForm";
	}
	
	@RequestMapping(value="/reservationModifyConfirm", method=RequestMethod.POST)
	public String reservationModifyConfirm(ReservationVo reservationVo) {
		
		System.out.println("[AdminController] reservationModifyConfirm() INIT");
		
		int result = reservationService.updateReservation(reservationVo);
		
		
		return "redirect:/admin/reservations";
	}
	
	@RequestMapping(value="/reservationCancel", method = RequestMethod.GET)
	public String reservationCancel(@RequestParam int r_no) {
		
		System.out.println("[AdminController] reservationCancel() INIT");
		
		int result = reservationService.deleteReservation(r_no);
		
		return "redirect:/admin/reservations";
	}
}
