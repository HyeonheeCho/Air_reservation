package com.air.service.member.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.air.service.member.vo.MemberVo;

@Component
public class MemberDao {
	
	public final static int MEMBER_IS_NOT = 0;
	public final static int MEMBER_IS = 1;
	public final static int MEMBER_INSERT_SUCCESS = 2;
	public final static int MEMBER_INSERT_FAIL = 3;
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	public int memberLogin(MemberVo memberVo) {
		
		int result = 0;
		
		String sql = "SELECT COUNT(*) FROM tbl_member WHERE m_mail=? and m_pw=?";
		
		result = jdbcTemplate.queryForObject(sql, Integer.class, memberVo.getM_mail(), memberVo.getM_pw());
		
		return result;
	}

	public int insertMember(MemberVo memberVo) {
		
		int result = 0;
		
		String sql = "INSERT INTO tbl_member(m_mail, m_pw, m_reg_date, m_mod_date) "
				+ "VALUES(?, ?, NOW(), NOW())";
		
		result = jdbcTemplate.update(sql, memberVo.getM_mail(), memberVo.getM_pw());
		
		if(result > 0) {
			
			return MEMBER_INSERT_SUCCESS;
		
		} else {
			
			return MEMBER_INSERT_FAIL;
		}
	
	
	}

	public List<MemberVo> selectMembers() {
		
		return null;
	}

	public boolean isMember(MemberVo memberVo) {
		
		int result = 0;
		
		String sql = "SELECT COUNT(*) FROM tbl_member WHERE m_mail=?";
		
		result = jdbcTemplate.queryForObject(sql, Integer.class, memberVo.getM_mail());
		
		return result > 0 ? true : false;
		
		
	}

	


	
	
}
