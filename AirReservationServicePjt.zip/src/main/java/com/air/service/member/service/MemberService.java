package com.air.service.member.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.air.service.member.dao.MemberDao;
import com.air.service.member.vo.MemberVo;

@Service
public class MemberService {

	@Autowired
	MemberDao memberDao;
	
	public int loginConfirm(MemberVo memberVo) {
		
		int result = memberDao.memberLogin(memberVo);
				
		return result;
	}

	 
	public List<MemberVo> getMembers() {
		
		List<MemberVo> memberVos = memberDao.selectMembers();
		
		return memberVos;
	}

	public int joinConfirm(MemberVo memberVo) {
	
		System.out.println("[MemberService] joinMember() INIT");
		
		if (memberDao.isMember(memberVo)) { 
			
			return MemberDao.MEMBER_IS;        
			
		} else {
			
			return memberDao.insertMember(memberVo);    
		}
	}
	
	
	
}
