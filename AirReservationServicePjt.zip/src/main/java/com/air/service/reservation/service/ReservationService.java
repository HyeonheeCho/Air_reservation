package com.air.service.reservation.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.air.service.reservation.dao.ReservationDao;
import com.air.service.reservation.vo.ReservationVo;

@Service
public class ReservationService {
	
	@Autowired
	ReservationDao reservationDao;

	public List<ReservationVo> insertReservation(ReservationVo reservationVo) {
		
		 int result = reservationDao.insertReservation(reservationVo);
		 
		 List<ReservationVo> reservationVos = null;
		 
		 if(result > 0) {
			 
			 reservationVos = reservationDao.selectReservationByMail(reservationVo.getR_mail());
		 }
		 
		 return reservationVos;
	}

	
	public ReservationVo getReservation(int r_no) {
		
		ReservationVo reservationVo = reservationDao.selectReservationByNo(r_no);
		
		return reservationVo;
	}

	public int updateReservation(ReservationVo reservationVo) {
		
		int result = reservationDao.updateReservation(reservationVo);
		
		return result;
	}

	public int deleteReservation(int r_no) {
		
		int result = reservationDao.deleteReservation(r_no);
		
		return result;
	}

	public List<ReservationVo> getReservations(String m_mail) {
		
		List<ReservationVo> reservationVos = reservationDao.selectReservationByMail(m_mail);
		
		return reservationVos;
	}


	public List<ReservationVo> getReservations() {
		
		List<ReservationVo> reservationVos = reservationDao.selectReservations();
		
		return reservationVos;
	}






	
	
}
